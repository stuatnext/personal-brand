# NEXTPredict LinkedIn Articles Source Pack

Created from the LinkedIn Articles material supplied on 16 July 2026.

## Coverage

- **9 attached LinkedIn article captures** preserved byte-for-byte.
- **22 inline article occurrences** catalogued from the long chat paste.
- **31 total source occurrences** represented.
- Duplicate occurrences were retained. The repeated Casino Guru `Spin of the Week` issue remains listed twice.

## Files

- `00_ORIGINAL_ATTACHED_CAPTURES/`: untouched copies of every attached source.
- `01_ATTACHED_ARTICLES_LOSSLESS.jsonl`: complete raw text and metadata for each attached capture.
- `02_ATTACHED_ARTICLES_INDEX.csv`: navigation index for attached captures.
- `03_INLINE_CHAT_ARTICLE_OCCURRENCE_INDEX.csv`: occurrence-level index of articles pasted directly into chat.
- `04_COMBINED_ARTICLE_CATALOGUE.csv`: one catalogue spanning both source layers.
- `05_VALIDATION_MANIFEST.json`: hashes, counts and integrity checks.

## Integrity note

The nine attached captures are fully lossless and hash-validated. The long multi-article text pasted
directly into the chat remains preserved in the conversation and is catalogued here, but ChatGPT did
not receive that composer body as a mountable file. It therefore cannot be represented as a byte-for-byte
original inside this ZIP without a separate text-file upload. No inline occurrence was silently removed.
