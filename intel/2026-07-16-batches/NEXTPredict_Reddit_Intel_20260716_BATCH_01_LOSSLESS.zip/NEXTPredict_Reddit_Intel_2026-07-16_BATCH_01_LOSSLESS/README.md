# NEXTPredict Reddit Intel Batch 01

Lossless archive created from 20 Reddit captures supplied on 16 July 2026.

## Integrity

- Source files: **20**
- Parsed Reddit page/post occurrences: **25**
- Removed or deleted post occurrences retained: **3**
- Locked post occurrences retained: **1**
- Captures containing rate-limit notices: **2**
- Promoted content blocks retained: **76**
- Total bytes preserved: **466,194**
- Exact duplicate source-file groups retained: **1**
- Exact duplicate occurrence groups retained: **1**
- Byte-for-byte preservation check: **True**
- Duplicates removed: **No**
- Comments removed: **No**
- Promoted content removed: **No**
- Moderation notices removed: **No**
- Rate-limit notices removed: **No**
- Sidebar/navigation material removed: **No**
- Editorial filtering: **None**

## Contents

- `00_ORIGINAL_CAPTURES/`: untouched copies of all 20 uploaded captures.
- `01_SOURCE_FILES_LOSSLESS.jsonl`: one complete raw record per source file.
- `02_REDDIT_OCCURRENCES_LOSSLESS.jsonl`: full raw text for each parsed Reddit occurrence.
- `03_SOURCE_FILE_MANIFEST.csv`: file hashes, counts and archive paths.
- `04_REDDIT_OCCURRENCE_INDEX.csv`: post/page-level navigation index.
- `05_DUPLICATE_MAP.json`: exact duplicate file and occurrence groups.
- `06_VALIDATION_MANIFEST.json`: validation results and archive totals.

## Important note

The batch retains complete comment threads, removed-post notices, moderator explanations, promoted posts,
subreddit rules, sidebars, rate-limit warnings, external links, reposted material, duplicate text and interface residue.
Occurrence parsing is only a navigation layer. Original captures and source-level JSONL are authoritative.
