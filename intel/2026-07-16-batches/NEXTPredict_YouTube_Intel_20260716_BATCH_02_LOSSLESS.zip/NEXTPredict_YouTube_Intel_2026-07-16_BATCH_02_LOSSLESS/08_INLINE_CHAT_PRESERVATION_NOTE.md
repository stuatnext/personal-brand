# Inline YouTube occurrences

Three YouTube pages were pasted directly into the user message but were not supplied as mounted source files:

1. Should prediction markets decide whether a CEO should be fired? — Henri Arslanian
2. Chris Van Hollen Asks Kagan And Barrett If Justices Will Be Prohibited From Using Prediction Markets — Forbes Breaking News
3. Examining Customer Protections and Market Integrity in Sports Event Prediction Markets — House Ag Democrats

They are catalogued in `07_INLINE_CHAT_OCCURRENCE_INDEX.csv`.

Because the conversation composer text was not mounted as a file, these three items cannot honestly be
represented as byte-for-byte archived or assigned source-file hashes. Their full text remains in the conversation
context. The 14 attached captures in `00_ORIGINAL_CAPTURES/` are preserved byte-for-byte.
