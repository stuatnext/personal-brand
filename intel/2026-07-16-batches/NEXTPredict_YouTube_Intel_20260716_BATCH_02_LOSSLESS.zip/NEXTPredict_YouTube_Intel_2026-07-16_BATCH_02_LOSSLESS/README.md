# NEXTPredict YouTube Intel Batch 02

Archive created from 14 mounted YouTube page/transcript captures plus 3 additional YouTube pages pasted inline on 16 July 2026.

## Integrity

- Mounted source files preserved byte-for-byte: **14**
- Mounted YouTube page occurrences: **14**
- Inline chat occurrences catalogued: **3**
- Total catalogued YouTube occurrences: **17**
- Occurrences containing transcript text: **14**
- Scheduled occurrences: **0**
- Streamed-live occurrences: **1**
- Total bytes preserved: **635,589**
- Exact duplicate source-file groups retained: **0**
- Exact duplicate occurrence groups retained: **0**
- Byte-for-byte preservation check: **True**
- Duplicates removed: **No**
- Comments removed: **No**
- Recommendations removed: **No**
- Non-English material removed: **No**
- Interface noise removed: **No**
- Editorial filtering: **None**

## Contents

- `00_ORIGINAL_CAPTURES/`: untouched copies of all 14 uploaded captures.
- `01_SOURCE_FILES_LOSSLESS.jsonl`: one complete raw record per source file.
- `02_YOUTUBE_OCCURRENCES_LOSSLESS.jsonl`: full raw text for each parsed YouTube page occurrence.
- `03_SOURCE_FILE_MANIFEST.csv`: file hashes, counts and archive paths.
- `04_YOUTUBE_OCCURRENCE_INDEX.csv`: video/page-level navigation index.
- `05_DUPLICATE_MAP.json`: exact duplicate file and occurrence groups.
- `06_VALIDATION_MANIFEST.json`: validation results and archive totals.
- `07_INLINE_CHAT_OCCURRENCE_INDEX.csv`: catalogue of the three pages pasted directly into chat.
- `08_INLINE_CHAT_PRESERVATION_NOTE.md`: explicit preservation limitation for the inline-only material.

## Important note

The batch retains scheduled-event pages, transcripts, comments, recommendation panels, chapter lists,
automatic transcript errors, unrelated suggested videos, promotional copy, non-English text and interface residue.
Occurrence parsing is only a navigational layer. The original captures and source-level JSONL are authoritative.

## Inline preservation limitation

The three pages pasted directly into chat are catalogued but are not represented as byte-perfect files, because no mounted source file was available. The 14 attached captures remain fully lossless and hash-validated.
