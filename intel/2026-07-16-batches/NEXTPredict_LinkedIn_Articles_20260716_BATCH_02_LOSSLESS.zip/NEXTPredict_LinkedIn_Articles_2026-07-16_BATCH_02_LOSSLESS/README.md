# NEXTPredict LinkedIn Articles Batch 02

Lossless source pack created from 16 LinkedIn article/newsletter captures supplied on 16 July 2026.

## Integrity

- Source files: **16**
- Parsed article/page occurrences: **33**
- Total bytes preserved: **335,811**
- Exact duplicate source-file groups retained: **1**
- Exact duplicate occurrence groups retained: **1**
- Byte-for-byte preservation check: **True**
- Duplicates removed: **No**
- Noise removed: **No**
- Editorial filtering: **None**

## Contents

- `00_ORIGINAL_CAPTURES/`: untouched copies of all 16 uploaded files.
- `01_SOURCE_FILES_LOSSLESS.jsonl`: one complete raw record per source file.
- `02_ARTICLE_OCCURRENCES_LOSSLESS.jsonl`: raw text for each parsed LinkedIn page/article occurrence.
- `03_SOURCE_FILE_MANIFEST.csv`: file-level hashes and counts.
- `04_ARTICLE_OCCURRENCE_INDEX.csv`: navigational index of parsed article occurrences.
- `05_DUPLICATE_MAP.json`: exact duplicate file and occurrence groups.
- `06_VALIDATION_MANIFEST.json`: integrity checks and totals.

## Important note

Occurrence parsing is only a navigation layer. Some uploads contain several LinkedIn pages concatenated together.
The original files and source-level JSONL are the authoritative lossless record and preserve every character,
comment, duplicated capture, interface fragment, URL, and irrelevant item exactly as supplied.
