# NEXTPredict News & Articles Batch 03

Lossless archive of 20 mounted web-page and article captures supplied on 16 July 2026.

## Validation

- Mounted source files: **20**
- Parsed article/page occurrences: **61**
- Source bytes preserved: **515,281**
- Source characters: **506,954**
- Source lines: **15,156**
- Byte-for-byte preservation check: **True**
- Exact duplicate source-file groups: **0**
- Exact duplicate occurrence groups: **0**
- Whitespace-normalized duplicate occurrence groups: **0**
- Same-title occurrence groups retained: **1**
- Missing navigational markers: **0**

## Preservation policy

Every mounted file is preserved untouched in `00_ORIGINAL_CAPTURES/`.
The source-level JSONL also includes the full raw text and SHA-256 hash for every file.

Article occurrence boundaries are navigational only. Concatenated files may contain publisher headers,
footers, advertisements, related-story modules, subscription prompts, price tickers, and unrelated pages.
None of that material was removed from the original captures or source-level JSONL.

The two Vanity Fair captures with the same headline remain as separate source occurrences.
Press releases, affiliate material, opinion pieces, subscriber pages, and unrelated page residue are retained.

## Contents

- `00_ORIGINAL_CAPTURES/`: untouched source files.
- `01_SOURCE_FILES_LOSSLESS.jsonl`: complete raw source records.
- `02_ARTICLE_OCCURRENCES_LOSSLESS.jsonl`: raw navigational article/page segments.
- `03_SOURCE_FILE_MANIFEST.csv`: file hashes and dimensions.
- `04_ARTICLE_OCCURRENCE_INDEX.csv`: article/page navigation.
- `05_DUPLICATE_MAP.json`: exact, normalized, and same-title duplicate groups.
- `06_VALIDATION_MANIFEST.json`: integrity and coverage checks.
- `README.md`: this guide.
