# NEXTPredict News & Articles Batch 04

Archive of newsletter, Substack, Medium, beehiiv and web-page captures supplied on 16 July 2026.

## Coverage

- Mounted source files: **20**
- Mounted article/newsletter occurrences: **35**
- Inline-chat occurrences catalogued separately: **2**
- Total catalogued occurrences: **37**
- Mounted source bytes: **422,584**
- Multi-occurrence mounted source files: **1**
- Largest concatenated source: **16 occurrences**
- Exact duplicate source-file groups retained: **2**
- Exact duplicate occurrence groups retained: **2**
- Mounted byte-for-byte preservation: **True**

## Preservation policy

All mounted source files are untouched in `00_ORIGINAL_CAPTURES/`.
Source-level JSONL includes each complete decoded capture and its SHA-256 hash.
Occurrence boundaries are navigational only. The original captures remain authoritative.

Advertisements, sponsor messages, paywalls, subscription prompts, comments, cookie notices,
navigation, unrelated stories and repeated captures were not removed.

The two Medium items pasted directly into chat are catalogued separately and are not falsely
represented as byte-perfect mounted files.

## Files

- `00_ORIGINAL_CAPTURES/`
- `01_SOURCE_FILES_LOSSLESS.jsonl`
- `02_ARTICLE_OCCURRENCES_LOSSLESS.jsonl`
- `03_SOURCE_FILE_MANIFEST.csv`
- `04_ARTICLE_OCCURRENCE_INDEX.csv`
- `05_DUPLICATE_MAP.json`
- `06_INLINE_CHAT_OCCURRENCE_INDEX.csv`
- `07_INLINE_CHAT_PRESERVATION_NOTE.md`
- `08_BATCH_CATALOGUE.csv`
- `09_VALIDATION_MANIFEST.json`
- `README.md`
