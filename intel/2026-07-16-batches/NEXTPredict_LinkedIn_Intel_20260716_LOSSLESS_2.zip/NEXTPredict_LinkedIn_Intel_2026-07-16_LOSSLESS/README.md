# NEXTPredict LinkedIn Intel Source Pack

Captured source: `Pasted text(2).txt`  
Post blocks preserved: **243**  
Original size: **360,128 bytes**  
SHA-256: `3d87f6a5a02643016849ade4a9a923fa2305b697d21cf58af1a73173c451fa4a`

## Files

- `00_ORIGINAL_LinkedIn_capture.txt`: canonical byte-for-byte copy of the supplied capture.
- `01_capture_preamble.txt`: LinkedIn search/filter material before the first feed post.
- `02_linkedin_posts_lossless.jsonl`: one record per feed-post block, retaining each block's complete raw text.
- `03_linkedin_posts_index.csv`: navigation index with author, timestamp, opening text and URLs.
- `04_validation_manifest.json`: integrity checks and source statistics.

## Lossless rules applied

No post was deleted because it appeared irrelevant, duplicated, promotional, malformed, translated, or low signal.  
No factual claim was corrected or overwritten in the archive.  
The original capture remains the canonical source. The structured records reconstruct the decoded source exactly: **True**.
