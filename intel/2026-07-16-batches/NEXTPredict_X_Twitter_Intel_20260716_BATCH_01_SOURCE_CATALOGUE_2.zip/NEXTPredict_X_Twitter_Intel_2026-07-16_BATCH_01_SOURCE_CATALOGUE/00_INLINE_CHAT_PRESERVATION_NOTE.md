# Inline chat preservation note

This X/Twitter material was pasted directly into the ChatGPT composer as several overlapping search-result views.

The chat composer is not exposed as a mounted, byte-addressable source file. Therefore:

- No source-byte SHA-256 hash is available.
- This archive does not claim byte-perfect or fully lossless preservation of the entire pasted text.
- It does preserve a structured catalogue of every clearly visible top-level timeline occurrence identified in the paste.
- Repeated posts remain repeated, because resurfacing and ranking across overlapping views may be analytically useful.
- Quoted posts, paid-partnership labels, AI labels, links, truncation markers, media durations and unrelated timeline residue are retained where visible.
- Search-interface residue is described in the capture-view manifest rather than reconstructed as a false raw source.

The user's original chat message remains the authoritative full-text source.
