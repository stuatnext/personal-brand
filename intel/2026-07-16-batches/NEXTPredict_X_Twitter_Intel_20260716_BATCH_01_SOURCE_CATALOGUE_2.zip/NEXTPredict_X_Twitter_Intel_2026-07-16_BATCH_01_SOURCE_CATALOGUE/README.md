# NEXTPredict X/Twitter Intel Batch 01

Structured source catalogue created from multiple overlapping X search-result views pasted directly into chat on 16 July 2026.

## Coverage

- Capture views: **8**
- Visible top-level timeline appearances: **93**
- Unique top-level posts: **38**
- Posts resurfacing across multiple views: **31**
- Paid-partnership appearances retained: **12**
- “Made with AI” appearances retained: **2**
- Truncated-preview appearances retained: **45**
- Appearances containing quoted-post metadata: **26**
- Unrelated timeline-residue appearances retained: **6**

## Integrity limitation

The source was pasted inline rather than uploaded as a mounted file. No byte hash is available and this archive does not claim byte-perfect preservation. The original user message is the authoritative full-text source.

## Files

- `00_INLINE_CHAT_PRESERVATION_NOTE.md`: source limitation and preservation policy.
- `01_X_TIMELINE_OCCURRENCES_CATALOGUE.jsonl`: one structured record for every visible timeline appearance.
- `02_X_TIMELINE_OCCURRENCE_INDEX.csv`: navigational occurrence index.
- `03_UNIQUE_POST_INDEX.csv`: unique-post index with appearance counts, links and quoted-post metadata.
- `04_DUPLICATE_RESURFACING_MAP.json`: repeated posts and every view/rank where they resurfaced.
- `05_CAPTURE_VIEW_MANIFEST.json`: ordered post lists and interface residue for each pasted search view.
- `06_VALIDATION_MANIFEST.json`: counts and preservation checks.

No posts were removed because they were promotional, repetitive, unrelated, AI-labelled, truncated or unverified.
