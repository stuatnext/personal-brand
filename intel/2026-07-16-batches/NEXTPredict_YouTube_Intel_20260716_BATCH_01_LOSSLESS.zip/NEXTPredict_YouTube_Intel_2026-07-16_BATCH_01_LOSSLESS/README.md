# NEXTPredict YouTube Intel Batch 01

Lossless archive created from 20 YouTube page and transcript captures supplied on 16 July 2026.

## Integrity

- Source files: **20**
- Parsed YouTube page occurrences: **20**
- Occurrences containing transcript text: **19**
- Total bytes preserved: **745,997**
- Exact duplicate source-file groups retained: **0**
- Exact duplicate occurrence groups retained: **0**
- Byte-for-byte preservation check: **True**
- Duplicates removed: **No**
- Comments removed: **No**
- Recommendations removed: **No**
- Interface noise removed: **No**
- Editorial filtering: **None**

## Contents

- `00_ORIGINAL_CAPTURES/`: untouched copies of all 20 uploaded text captures.
- `01_SOURCE_FILES_LOSSLESS.jsonl`: one complete raw record per source file.
- `02_YOUTUBE_OCCURRENCES_LOSSLESS.jsonl`: full raw text for every parsed YouTube page occurrence.
- `03_SOURCE_FILE_MANIFEST.csv`: file hashes, counts and archive paths.
- `04_YOUTUBE_OCCURRENCE_INDEX.csv`: video-level navigation index.
- `05_DUPLICATE_MAP.json`: exact duplicate file and occurrence groups.
- `06_VALIDATION_MANIFEST.json`: validation results and archive totals.

## Important note

Some captures contain more than one YouTube page or include recommendations, comments, chapter lists,
live chat residue, auto-generated transcript text and unrelated suggested videos. None of this has been removed.
Occurrence parsing is only a navigation layer. The original source captures and source-level JSONL are authoritative.
