# NEXTPredict News & Articles Batch 05

Archive of Medium and related article captures supplied on 16 July 2026.

## Coverage

- Mounted source files: **10**
- Mounted article occurrences: **10**
- Inline-chat occurrences catalogued separately: **22**
- Total catalogued occurrences: **32**
- Mounted source bytes: **151,219**
- Exact duplicate source-file groups retained: **1**
- Largest exact duplicate group: **3 files**
- Mounted byte-for-byte preservation: **True**

## Preservation policy

All mounted captures are untouched in `00_ORIGINAL_CAPTURES/`.
The source-level JSONL contains the complete decoded text and SHA-256 hash for every mounted file.
The three Baozilla captures are exact duplicates and have all been retained.

The 22 items pasted directly into chat are catalogued separately and are not falsely represented
as mounted or byte-perfect. Paywalls, adverts, navigation, recommendation cards, unrelated material
and promotional invite-code content are not silently removed.

## Files

- `00_ORIGINAL_CAPTURES/`
- `01_SOURCE_FILES_LOSSLESS.jsonl`
- `02_MOUNTED_ARTICLE_OCCURRENCES_LOSSLESS.jsonl`
- `03_SOURCE_FILE_MANIFEST.csv`
- `04_MOUNTED_ARTICLE_OCCURRENCE_INDEX.csv`
- `05_DUPLICATE_MAP.json`
- `06_INLINE_CHAT_OCCURRENCE_INDEX.csv`
- `07_INLINE_CHAT_PRESERVATION_NOTE.md`
- `08_BATCH_CATALOGUE.csv`
- `09_VALIDATION_MANIFEST.json`
- `README.md`
