# Inline chat preservation note

The long Medium export in the user message contains 22 top-level article, page or collection
occurrences. These were pasted directly into the chat composer and were not supplied as
byte-addressable mounted files.

They are catalogued in `06_INLINE_CHAT_OCCURRENCE_INDEX.csv`. This archive does not claim
byte-perfect preservation, complete raw-text reconstruction, or SHA-256 hashes for those 22 items.

The original user message remains the authoritative source for the full pasted text.

The Auktavian Garrett `Ai try out videos` entry is retained as one collection/feed-page occurrence.
Its embedded recommendation cards and unrelated material are noted rather than silently discarded.
