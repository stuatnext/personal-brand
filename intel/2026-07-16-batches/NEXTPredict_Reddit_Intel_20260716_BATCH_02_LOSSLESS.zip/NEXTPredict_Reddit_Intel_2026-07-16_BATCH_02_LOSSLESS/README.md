# NEXTPredict Reddit Intel Batch 02

Archive created from two mounted captures and eleven Reddit pages pasted directly into chat on 16 July 2026.

- Mounted source files: **2**
- Mounted Reddit occurrences: **14**
- Inline chat occurrences catalogued: **11**
- Total catalogued occurrences: **25**
- Mounted bytes preserved: **80,881**
- Byte-for-byte mounted-file check: **True**
- Exact duplicate mounted occurrence groups retained: **1**
- Mounted removed/deleted occurrences retained: **2**
- Inline removed/locked occurrence catalogued: **1**
- Rate-limit captures retained: **1**
- Server-error captures retained: **2**
- Promoted blocks retained in mounted sources: **24**
- Duplicates, comments, ads, moderation notices, navigation and unrelated material removed: **No**

The repeated NinjaTrader post remains twice. The unrelated Wealthsimple RRSP page remains because it was supplied.
Inline chat text is catalogued but is not falsely represented as byte-perfect.
