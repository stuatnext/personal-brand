# Inline chat preservation note

Eleven Reddit page captures were pasted directly into chat rather than mounted as standalone files. They are catalogued in `07_INLINE_CHAT_OCCURRENCE_INDEX.csv`. Because the chat composer is not exposed as a byte-addressable source file, these inline captures cannot honestly be assigned byte hashes or claimed as byte-perfect copies. No complete-text reconstruction or silent normalization was attempted.
